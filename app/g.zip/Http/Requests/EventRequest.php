<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class EventRequest extends \App\Http\Requests\BaseCustomRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'required|string',
            'type' => 'required|string',
            'tickets' => 'required|integer',
            'date' => 'required',
            'isFree' => 'required|boolean',
            'pricing' => 'required',
            'price' => 'required_if:pricing,sinple',
            'ticketCategories' => 'required_if:pricing,multiple',
            'description' => 'required|string',
        ];
    }
}
