<?php

namespace App\Http\Controllers\Organization;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Auth;
use App\Models\Subscription;
use App\Http\Resources\SubscriptionResource;

class SubscriptionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $subs = Subscription::where('organization_id', Auth::user()->typeData->id)
            ->latest()
            ->paginate(10);

        return $this->jsonPaginatedResponse('Subscriptions', SubscriptionResource::collection($subs));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $request->validate([
            'status' => 'required',
            'member_id'=>'required|numeric',
            'category_id'=>'required|numeric',
            'organization_id'=>'required|numeric',
            'organization_id' => 'required|numeric',
        ]); 

        // $member = Subscription::create([
        //     'user_id' => $user->id, 
        //     'type' => 'organization', 
        //     'owner_id' => $org->id], 
        //     [
        //         'status' => 'pending'
        //     ]
        // );

        return response([
            'status' => true,
            'message' => 'Member added successfully',
            'data' => new MemberResource($member)
        ]);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
