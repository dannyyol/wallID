<?php

namespace App\Http\Controllers\Organization;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Auth;
use App\Models\User;
use App\Models\Member;
use App\Models\Organization;
use App\Http\Resources\MemberResource;

use App\Handlers\NotificationHandler;

class MemberController extends Controller
{
    use NotificationHandler;

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $members = Member::where('org_id', Auth::user()->typeData->id)
            ->where('status', '!=', 'pending')
            ->get();
            
        return response([
            'status' => true,
            'message' => 'Members',
            'data' => MemberResource::collection($members)
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'user' => 'required|string'
        ]);

        $user = User::findOrFail($this->decodeId($request->user));
        $org = Organization::where('user_id', Auth::user()->id)->first();

        $member = Member::firstOrCreate([
            'user_id' => $user->id, 
            'type' => 'organization', 
            'owner_id' => $org->id], 
            [
                'status' => 'pending'
            ]
        );

        return response([
            'status' => true,
            'message' => 'Member added successfully',
            'data' => new MemberResource($member)
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $member = Member::findOrFail($this->decodeId($id));
        return response([
            'status' => false,
            'message' => 'Member fetched successfully',
            'data' => new MemberResource($member)
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function approve($id)
    {
        
        $org = Organization::where('user_id', Auth::user()->id)->first();
        $member = Member::where('org_id', $org->id)
            ->where('id', $this->decodeId($id))->first();

        if ($member) {

            $member->status = 'approved';
            $member->save();
            
            try {
                $user = User::findOrFail($member->user_id);
                $this->sendApprovalNotification($user);
            } catch (\Exception $e) {
                info('Error 101 ' . $e->getMessage());
            }

            return response([
                'status' => true,
                'message' => 'Member approved successfully']);
        }

        return response([
            'status' => false,
            'message' => 'Member ID not recognized']);
    }

    public function updateStatus($id, $status)
    {
        $org = Organization::where('user_id', Auth::user()->id)->first();

        $member = Member::where('owner_id', $org->id)
            ->where('id', $this->decodeId($id))
            ->where('type', 'organization')->first();

        if ($member) {

            $member->status = $status;
            $member->save();
            
            return response([
                'status' => true,
                'message' => 'Member status updated successfully']);
        }

        return response([
            'status' => false,
            'message' => 'Member ID not recognized']);
    }

    public function requests()
    {
        $requests = Member::where('org_id', Auth::user()->typeData->id)
            ->where('status', 'pending')
            ->latest()
            ->paginate();

        return $this->jsonPaginatedResponse('Membership Requests', MemberResource::collection($requests));
    }

    public function addApprove(Request $request)
    {

        $request->validate([
            'user' => 'required',
            'category_id' => 'required'
        ]);

        $member = Member::firstOrCreate(
            [
                'org_id' => Auth::user()->typeData->id,
                'individual_id' => $this->decodeId($request->user)
            ],
            [
                'status' => 'approved',
                'category_id' => $request->category_id
            ]
        );

        return response([
            'status' => false,
            'message' => 'Member added successfully',
            'data' => new MemberResource($member)
        ]);
    }
}
