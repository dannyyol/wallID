<?php

namespace App\Http\Controllers\Api\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\User;
use Illuminate\Support\Facades\Hash;

use App\Http\Requests\Auth\RegisterRequest;
use App\Http\Requests\Auth\RegisterOrgRequest;

use App\Models\Individual;
use App\Models\Organization;

use App\Http\Resources\UserResource;
use App\Http\Requests\Auth\LoginRequest;


class AuthController extends Controller
{
    //

     // API
     public function login(LoginRequest $request)
     {
         $request->validated();
         $user = User::query()->where('email', $request->email)->first();
 
         if(!$user || !Hash::check($request->password, $user->password)) {
             return $this->sendCodedResponse(401, 'Invalid credentials', null, false);
         }
 
         // if (!$user->email_verified_at) {
         //     return $this->sendCodedResponse(401, 'Email has not been verified', null, false);
         // }
 
         $token = $this->createAuthToken($request->email, $request->password);
         return response([
             'status' => true,
             'message' => 'Login Successfully',
             'data' => [
                 'tokens' => $token,
                 'user' => new UserResource($user)
             ]
         ]);
     }
 
    public function register(RegisterRequest $request)
    {
        try {

            $input = $request->validated();
            $user = $this->create($input);

            $individual = Individual::create([
                'firstname' => $input['firstname'],
                'lastname' => $input['lastname'],
                'phone' => $input['phone'],
                'user_id' => $user->id
            ]);

            $token = $this->createAuthToken($request->email, $request->password);
            $response = [
                'status' => true,
                'message' =>  'Account created Successfully',
                'data' => [
                    'tokens' => $token,
                    'user' => new UserResource($user)
                ]
            ];

            $this->assignRoles($user, 'individual');

            try {
                $this->sendEmailVerificationNotification($user);
            } 
            catch (\Exception $e) {
                
            }

            return response($response);

        } catch (\Exception $e) {

            if(isset($user)) 
                $user->delete();

            throw $e;
        }
    }

    /**
     * Store a newly created resource i\n storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function registerOrganization(RegisterOrgRequest $request)
    {
        try {

            $request->validated();
            $user = User::create([
                'type' => 'organization',
                'email' => $request->email,
                'username' => $request->name,
                'password' => Hash::make($request->password)]);

            $org = Organization::create([
                'name' => $request->input('name'),
                'user_id' => $user->id,
                'phone' => $request->phone,
                'employees' => $request->input('employees')]);

            $token = $this->createAuthToken($request->email, $request->password);
            $response = [
                'status' => true,
                'message' =>  'Account created Successfully',
                'data' => [
                    'tokens' => $token,
                    'user' => new UserResource($user)
                ]
            ];

            $this->assignRoles($user, 'organization');
            
            return response($response);

        } catch (\Exception $e) {
            
            if(isset($user)) 
                $user->delete();

            if(isset($org)) 
                $org->delete();

            throw $e;
        }
    }


   
}
