<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'tickets', 'type', 'status', 'user_id', 'description', 'price', 'isFree', 'event_date', 'pricing', 'unique_id'];

    public function user()
    {
        return $this->belongsTo('App\Models\User');
    }

    public function tickets()
    {
        return $this->hasMany('App\Models\Ticket');
    }

    public function attendees()
    {
        return $this->hasMany('App\Models\Attendee');
    } 

    public function ticketCategories()
    {
        return $this->hasMany('App\Models\TicketCategory');
    }    
}
