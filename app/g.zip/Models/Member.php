<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Member extends Model
{
    use HasFactory;

    protected $fillable = ['individual_id', 'type', 'status', 'org_id'];

    public function individual()
    {
        return $this->belongsTo('App\Models\Individual');
    }

    public function organization()
    {
        return $this->belongsTo('App\Models\Organization', 'org_id');
    }
}